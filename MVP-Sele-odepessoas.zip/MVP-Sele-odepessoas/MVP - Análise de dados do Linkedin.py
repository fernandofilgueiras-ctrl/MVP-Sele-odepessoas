# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T

CATALOG = "main"
SCHEMA  = "mvp_talent"

TBL_BRONZE = f"{CATALOG}.{SCHEMA}.bronze_linkedin_people_raw"
TBL_SILVER = f"{CATALOG}.{SCHEMA}.silver_linkedin_people_clean"
TBL_GOLD_DASH = f"{CATALOG}.{SCHEMA}.gold_candidate_dashboard"
TBL_GOLD_FEATURES = f"{CATALOG}.{SCHEMA}.gold_candidate_features"

SOURCE_SQL = """
SELECT * 
FROM `bright_data_business_information_linkedin_listing`.`datasets`.`linked_in_people_profiles_datasets`
"""

# COMMAND ----------
# =========================
# CONFIGURAÇÃO DO MVP
# =========================
CATALOG = "main"          # Unity Catalog (ajuste se necessário)
SCHEMA  = "mvp_talent"    # schema/database destino

TBL_BRONZE = f"{CATALOG}.{SCHEMA}.bronze_linkedin_people_raw"
TBL_SILVER = f"{CATALOG}.{SCHEMA}.silver_linkedin_people_clean"
TBL_GOLD_DASH = f"{CATALOG}.{SCHEMA}.gold_candidate_dashboard"
TBL_GOLD_FEATURES = f"{CATALOG}.{SCHEMA}.gold_candidate_features"

SOURCE_SQL = """
SELECT * 
FROM `bright_data_business_information_linkedin_listing`.`datasets`.`linked_in_people_profiles_datasets`
"""

# Colunas possivelmente JSON/array no dataset (heurística)
JSON_CANDIDATE_COLS = [
    "experiences", "experience", "positions",
    "educations", "education",
    "skills", "certifications",
    "languages", "projects"
]

# Bootstrap do ambiente

# COMMAND ----------
def bootstrap_environment(catalog: str, schema: str) -> None:
    spark.sql(f"CREATE CATALOG IF NOT EXISTS {catalog}")
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
    spark.sql(f"USE {catalog}.{schema}")

bootstrap_environment(CATALOG, SCHEMA)
print(f"OK - usando {CATALOG}.{SCHEMA}")

# Funções utiitárias

# COMMAND ----------
def has_col(df, colname: str) -> bool:
    return colname in df.columns

def normalize_str(col):
    # lower, remove controles, colapsa espaços, trim
    return F.trim(
        F.regexp_replace(
            F.regexp_replace(F.lower(col), r"[\u0000-\u001f]", ""),
            r"\s+", " "
        )
    )

def coalesce_first(df, candidates, default=None):
    cols = [F.col(c) for c in candidates if has_col(df, c)]
    return F.coalesce(*cols) if cols else F.lit(default)

def infer_and_parse_json(
    df,
    colname: str,
    sample_rows: int = 2000
):
    """
    Se colname for string e parecer JSON, cria colname_struct (struct/array) via schema_of_json + from_json.
    Se não conseguir inferir, retorna df inalterado.
    """
    if not has_col(df, colname):
        return df

    dtype = df.schema[colname].dataType
    if not isinstance(dtype, T.StringType):
        return df

    sample = (
        df.select(colname)
          .where(F.col(colname).isNotNull())
          .where(F.col(colname).rlike(r"^\s*[\{\[]"))  # começa com { ou [
          .limit(sample_rows)
    )

    # Se não houver amostra válida, não faz nada
    if sample.count() == 0:
        return df

    schema_row = sample.select(
        F.schema_of_json(F.col(colname)).alias("schema")
    ).limit(1).collect()
    if not schema_row or schema_row[0]["schema"] is None:
        return df

    schema_str = schema_row[0]["schema"]
    return df.withColumn(
        f"{colname}_struct",
        F.from_json(F.col(colname), schema_str)
    )

def add_standard_person_fields(df):
    """
# Cria campos padronizados para o MVP, a partir de possíveis nomes de coluna.
    """
    full_name = coalesce_first(df, ["full_name", "name", "person_name", "profile_name"], default=None)
    headline  = coalesce_first(df, ["headline", "title", "job_title", "position"], default=None)
    location  = coalesce_first(df, ["location", "geo", "city", "region"], default=None)
    industry  = coalesce_first(df, ["industry", "sector"], default=None)
    profile_url = coalesce_first(df, ["profile_url", "linkedin_url", "url"], default=None)

    return (df
        .withColumn("person_full_name", normalize_str(full_name))
        .withColumn("person_headline", normalize_str(headline))
        .withColumn("person_location", normalize_str(location))
        .withColumn("person_industry", normalize_str(industry))
        .withColumn("person_profile_url", profile_url)
    )

def make_person_key(df):
    return F.sha2(
        F.concat_ws("||",
            F.coalesce(F.col("person_profile_url"), F.lit("")),
            F.coalesce(F.col("person_full_name"), F.lit("")),
            F.coalesce(F.col("person_headline"), F.lit("")),
            F.coalesce(F.col("person_location"), F.lit(""))
        ),
        256
    )

def write_delta_table(df, table_name: str, mode: str = "overwrite"):
    (df.write
      .format("delta")
      .mode(mode)
      .option("overwriteSchema", "true")
      .saveAsTable(table_name))

# Etapa bronze

# COMMAND ----------
def build_bronze(source_sql: str, bronze_table: str):
    df_src = spark.sql(source_sql)
    df_bronze = (
        df_src
        .withColumn("_ingest_ts", F.current_timestamp())
        .withColumn("_source", F.lit("bright_data_business_information_linkedin_listing.datasets.linked_in_people_profiles_datasets"))
    )
    write_delta_table(df_bronze, bronze_table, mode="overwrite")
    return df_bronze

df_bronze = build_bronze(SOURCE_SQL, TBL_BRONZE)
print("Bronze OK:", TBL_BRONZE, "rows:", df_bronze.count())
display(spark.table(TBL_BRONZE).limit(10))

# Etapa Silver

# COMMAND ----------
def build_silver(bronze_table: str, silver_table: str, json_cols: list):
    df = spark.table(bronze_table)

    # Parsing heurístico de JSON em colunas candidatas
    for c in json_cols:
        df = infer_and_parse_json(df, c)

    # Campos padronizados + auditoria
    df = (df
          .transform(add_standard_person_fields)
          .withColumn("_silver_ts", F.current_timestamp())
          .withColumn("person_key", make_person_key(df))
    )

    # Deduplicação por chave
    df = df.dropDuplicates(["person_key"])

    write_delta_table(df, silver_table, mode="overwrite")
    return df

df_silver = build_silver(TBL_BRONZE, TBL_SILVER, JSON_CANDIDATE_COLS)
print("Silver OK:", TBL_SILVER, "rows:", df_silver.count())
display(spark.table(TBL_SILVER).select(
    "person_key","person_full_name","person_headline","person_location","person_industry","person_profile_url"
).limit(20))

# Etapa gold - para dashboard

# COMMAND ----------
def seniority_bucket(headline_col):
    h = F.coalesce(headline_col, F.lit(""))
    return (F.when(h.rlike("(?i)intern|estagi"), F.lit("intern"))
             .when(h.rlike("(?i)junior|jr\\b"), F.lit("junior"))
             .when(h.rlike("(?i)pleno|mid|ii\\b"), F.lit("mid"))
             .when(h.rlike("(?i)senior|sr\\b|iii\\b|staff|principal"), F.lit("senior+"))
             .when(h.rlike("(?i)manager|lead|head|diretor|director"), F.lit("leadership"))
             .otherwise(F.lit("unknown")))

def build_gold_dashboard(silver_table: str, gold_table: str):
    df = spark.table(silver_table)

    completeness = (
        (F.col("person_full_name").isNotNull()).cast("int") +
        (F.col("person_headline").isNotNull()).cast("int") +
        (F.col("person_location").isNotNull()).cast("int") +
        (F.col("person_industry").isNotNull()).cast("int") +
        (F.col("person_profile_url").isNotNull()).cast("int")
    )

    # Contagens opcionais (se existirem estruturas/arrays)
    skills_count = F.lit(None).cast("int")
    if "skills_struct" in df.columns:
        skills_count = F.size(F.col("skills_struct"))
    elif has_col(df, "skills") and isinstance(df.schema["skills"].dataType, T.ArrayType):
        skills_count = F.size(F.col("skills"))

    exp_count = F.lit(None).cast("int")
    if "experiences_struct" in df.columns:
        exp_count = F.size(F.col("experiences_struct"))
    elif has_col(df, "experiences") and isinstance(df.schema["experiences"].dataType, T.ArrayType):
        exp_count = F.size(F.col("experiences"))

    df_gold = (
        df.select(
            "person_key",
            "person_full_name",
            "person_headline",
            "person_location",
            "person_industry",
            "person_profile_url",
            completeness.alias("profile_completeness_score"),
            seniority_bucket(F.col("person_headline")).alias("seniority_bucket"),
            skills_count.alias("skills_count"),
            exp_count.alias("experience_items_count"),
            F.current_timestamp().alias("_gold_ts")
        )
    )

    write_delta_table(df_gold, gold_table, mode="overwrite")
    return df_gold

df_gold_dash = build_gold_dashboard(TBL_SILVER, TBL_GOLD_DASH)
print("Gold Dashboard OK:", TBL_GOLD_DASH, "rows:", df_gold_dash.count())
display(spark.table(TBL_GOLD_DASH).orderBy(F.desc("profile_completeness_score")).limit(25))

# Etapa gold - Features para ML

# COMMAND ----------
def build_gold_features(gold_dashboard_table: str, gold_features_table: str):
    df = spark.table(gold_dashboard_table)

    df_feat = (
        df.withColumn(
            "text_profile",
            F.concat_ws(" | ",
                F.coalesce(F.col("person_headline"), F.lit("")),
                F.coalesce(F.col("person_industry"), F.lit("")),
                F.coalesce(F.col("person_location"), F.lit(""))
            )
        )
        .withColumn("skills_count", F.coalesce(F.col("skills_count"), F.lit(0)))
        .withColumn("experience_items_count", F.coalesce(F.col("experience_items_count"), F.lit(0)))
        .withColumn("profile_completeness_score", F.coalesce(F.col("profile_completeness_score"), F.lit(0)))
        .select(
            "person_key",
            "person_full_name",
            "person_profile_url",
            "seniority_bucket",
            "person_location",
            "person_industry",
            "skills_count",
            "experience_items_count",
            "profile_completeness_score",
            "text_profile",
            F.current_timestamp().alias("_features_ts")
        )
    )

    write_delta_table(df_feat, gold_features_table, mode="overwrite")
    return df_feat

df_gold_feat = build_gold_features(TBL_GOLD_DASH, TBL_GOLD_FEATURES)
print("Gold Features OK:", TBL_GOLD_FEATURES, "rows:", df_gold_feat.count())
display(spark.table(TBL_GOLD_FEATURES).limit(20))

# Baseline de matching por descrição de vaga

# COMMAND ----------
def rank_candidates_by_job_description(features_table: str, job_description: str, top_n: int = 50):
    df = spark.table(features_table)

    tokens = [t.strip().lower() for t in job_description.replace("\n", " ").split(" ") if len(t.strip()) >= 4]
    tokens = list(dict.fromkeys(tokens))[:50]

    score_expr = None
    for t in tokens:
        safe = "".join([ch for ch in t if ch.isalnum() or ch in ["_", "-"]])
        e = F.when(F.col("text_profile").rlike(f"(?i)\\b{safe}\\b"), 1).otherwise(0)
        score_expr = e if score_expr is None else (score_expr + e)

    ranked = (df
        .withColumn("job_match_score_baseline", F.coalesce(score_expr, F.lit(0)))
        .orderBy(F.desc("job_match_score_baseline"), F.desc("profile_completeness_score"))
    )
    return ranked.limit(top_n)

job_description = """
Data Engineer with Databricks, Delta Lake, ETL pipelines, Spark, Python, medallion architecture.
Experience with BI dashboards and ML feature engineering is a plus.
"""

display(rank_candidates_by_job_description(TBL_GOLD_FEATURES, job_description, top_n=50))

